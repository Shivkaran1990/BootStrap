package com.inq.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.inq.dao.InquiryService;
import com.inq.exel.InquiryListExelView;

@RestController
public class InquiryController {

	@Autowired
	InquiryService inquiryService;
	
	@Autowired
	InquiryListExelView InquiryListExelView;
	

	
	@RequestMapping(value = "/search/{name}", method = RequestMethod.GET, produces = "application/json")
	public List<Inquiry> search(@PathVariable("name") String name) {
			List<Inquiry> inquiryList = inquiryService.search(name);
		return inquiryList;
	}
	
	
	@RequestMapping(value = "/report", method = RequestMethod.GET, produces = "application/json")
	public List<Inquiry> reportData() {
			List<Inquiry> inquiryList = inquiryService.search("doe");
		return inquiryList;
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ModelAndView getInqDetails(@PathVariable("id") String id) {
		ModelAndView mv = new ModelAndView("home");
		Inquiry inquiry;
		if (id != null) {
			List<Inquiry> list = inquiryService.getInqData(id);
			inquiry = list.get(0);
			mv.addObject("inquiry", inquiry);
		} else {
			inquiry = new Inquiry();
			mv.addObject("inquiry", inquiry);
		}
		mv.addObject("home", true);
		return mv;
	}
	
	@RequestMapping(value = "/inquiryreport", method = RequestMethod.GET)
	public ModelAndView report() {
	/*	Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		formatter = new SimpleDateFormat("dd MMM yyyy");
		String strDate = formatter.format(date);
		List<Inquiry> inqList = inquiryService.report(strDate);*/
		List<Inquiry> inquirList = inquiryService.getInqData("90467771F");
		//inquiryListExelView.buildExcelDocument();
		ModelAndView mv= new ModelAndView( "inquiryreport");
		mv.addObject("inquirList", inquirList);
		return mv;
	}
	
	 @RequestMapping(value = "/updateInquiry", method = RequestMethod.POST)
	  public ModelAndView updateInqDetails(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("inquiry") Inquiry inquiry) {
		 ModelAndView mv = new ModelAndView("home");
		 inquiryService.updateInquiry(inquiry);
	  return mv;
	  }
	
	 @PostMapping("/fileUpload")
		public ResponseEntity<Object> fileUpload(@RequestParam("file") MultipartFile file) throws IOException {
			if (!file.getOriginalFilename().isEmpty()) {
				InputStream in = file.getInputStream();

				byte[] bytes = file.getBytes();
	            String completeData = new String(bytes);
	            String[] rows = completeData.split("#");
	            String[] columns = rows[0].split(",");
	            System.out.println(columns);
				/*BufferedReader br = new BufferedReader(new InputStreamReader(in));
				String line=null;
			     while ((line = br.readLine()) != null) {
			          System.out.println(line.toString());
			     }*/
			/*	File currDir = new File(".");
				String path = currDir.getAbsolutePath();
				String fileLocation = path.substring(0, path.length() - 1) + file.getOriginalFilename();
				FileInputStream excelFile = new FileInputStream(new File(fileLocation));

				Workbook workbook = new XSSFWorkbook(excelFile);
				Sheet datatypeSheet = workbook.getSheetAt(0);
				Iterator<Row> iterator = datatypeSheet.iterator();
				int count = 0;
				Inquiry inquiry;*/
			/*	while (iterator.hasNext()) {
					count = count + 1;
					Row currentRow = iterator.next();

					if (count > 3) {
						inquiry = ExelToBussinessObjectMapping.mapInquiry(currentRow);
						if (inquiry.getInq_ids() != null)
							inquiryService.saveInquiryDetials(inquiry);
					}
					System.out.println();
				}*/
			} else {
				return new ResponseEntity<>("Invalid file.", HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<>("File Uploaded Successfully.", HttpStatus.OK);
		}
	/*   @GetMapping("/upload")
		public String uploadform(String Id) {
			return "fileUploadForm";
		}*/
		@RequestMapping(value = "/getInq/{id}", method = RequestMethod.GET)
		public String getDataBasedOnID(@PathVariable("id") String id, Model model) {
			List<Inquiry> inqs = inquiryService.getInqData(id);
			model.addAttribute("inqdetails", inqs.get(0));

			return "home";
		}

		@RequestMapping(value = "/inq/update", method = RequestMethod.PUT)
		public String updateInq(@ModelAttribute("Inquiry") Inquiry inq) {
			this.inquiryService.updateInquiry(inq);
			return "home";
		}

	
		
	
/*	@RequestMapping("/getDetails/{id}")
	public List<Inquiry> getAllProducts(@PathVariable("id") String id)
	{
		System.out.print("we are here");
		System.out.print("we are here");
		System.out.print("we are here");
		
		List<Inquiry> list=inquiryService.getInqData(id);
		System.out.print("we are here");
		return list;       
	}*/
	
	/* @RequestMapping(value = "/updateInquiry", method = RequestMethod.POST)
	    public String submit(@ModelAttribute("inquiry") Inquiry inquiry,BindingResult result, ModelMap model) {
	        if (result.hasErrors()) {
	            return "error";
	        }
	        System.out.print("we are here");
	        model.addAttribute("name", employee.getName());
	        model.addAttribute("id", employee.getId());
	 
	        employeeMap.put(employee.getId(), employee);
	        System.out.print("we are here");
	        System.out.print("we are here");
	        return "employeeView";
	    }*/

/*	@RequestMapping(value = "/getDetails/{id}", method = RequestMethod.GET)
	public ModelAndView manageProduct(@PathVariable("id") String id) {
		ModelAndView mv = new ModelAndView("showInquiryDetails");
		List<Inquiry> list=inquiryService.getInqData(id);
		Inquiry inquiry=list.get(0);
		mv.addObject("inquiry", inquiry);
		mv.addObject("inqdetails", true);
		
		return mv;
	}*/
	
}
