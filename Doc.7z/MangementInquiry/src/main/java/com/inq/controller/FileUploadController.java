package com.inq.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.inq.dao.InquiryService;


	
/**
 * @author imssbora
 */
@Controller
public class FileUploadController {
	@Autowired
	InquiryService inquiryService;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView home() {
		ModelAndView mv = new ModelAndView("home");
		Inquiry inquiry = new Inquiry();
		mv.addObject("inquiry", inquiry);
		mv.addObject("home", true);
		return mv;
	}
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public ModelAndView inquiryHome() {
		ModelAndView mv = new ModelAndView("home");
		Inquiry inquiry = new Inquiry();
		mv.addObject("inquiry", inquiry);
		mv.addObject("home", true);
		return mv;
	}
	/*@GetMapping("/upload")
	public String uploadform(String Id) {
		return "fileUploadForm";
	}*/
	@RequestMapping(value = "/upload", method = RequestMethod.GET)
	public ModelAndView uploadPage() {
		ModelAndView mv = new ModelAndView("fileUploadForm");
		Inquiry inquiry = new Inquiry();
		return mv;
	}
/*
	@PostMapping("/fileUpload")
	public ResponseEntity<Object> fileUpload(@RequestParam("file") MultipartFile file) throws IOException {
		if (!file.getOriginalFilename().isEmpty()) {
			InputStream in = file.getInputStream();
			File currDir = new File(".");
			String path = currDir.getAbsolutePath();
			String fileLocation = path.substring(0, path.length() - 1) + file.getOriginalFilename();
			FileInputStream excelFile = new FileInputStream(new File(fileLocation));
			Workbook workbook = new XSSFWorkbook(excelFile);
			Sheet datatypeSheet = workbook.getSheetAt(0);
			Iterator<Row> iterator = datatypeSheet.iterator();
			int count = 0;
			Inquiry inquiry;
			while (iterator.hasNext()) {
				count = count + 1;
				Row currentRow = iterator.next();

				if (count > 3) {
					inquiry = ExelToBussinessObjectMapping.mapInquiry(currentRow);
					if (inquiry.getInq_ids() != null)
						inquiryService.saveInquiryDetials(inquiry);
				}
				System.out.println();
			}
		} else {
			return new ResponseEntity<>("Invalid file.", HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>("File Uploaded Successfully.", HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getInq/{id}", method = RequestMethod.GET)
	public String getDataBasedOnID(@PathVariable("id") String id, Model model) {
		List<Inquiry> inqs = inquiryService.getInqData(id);
		model.addAttribute("inqdetails", inqs.get(0));

		return "home";
	}

	@RequestMapping(value = "/inq/update", method = RequestMethod.PUT)
	public String updateInq(@ModelAttribute("Inquiry") Inquiry inq) {
		this.inquiryService.updateInquiry(inq);
		return "home";
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView inquiryHome() {
		ModelAndView mv = new ModelAndView("home");
		Inquiry inquiry = new Inquiry();
		mv.addObject("inquiry", inquiry);
		mv.addObject("home", true);
		return mv;
	}*/
	

	
	
/*	@RequestMapping("/home/{id}")
	public ModelAndView getInqDetails(@PathVariable("id") String id)  {
		ModelAndView mv = new ModelAndView("showInquiryDetails");
		List<Inquiry> list=inquiryService.getInqData(id);
		Inquiry inquiry=list.get(0);
		mv.addObject("inquiry", inquiry);
		return mv;
	}*/
/*	@GetMapping("/upload")
	public String uploadform(String Id) {
		return "fileUploadForm";
	}*/
	
	/*@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView register() {
		ModelAndView mv = new ModelAndView("register");
		User user=new User();
		user.setAddress("Mandsaur MP");
		user.setEmail("S.ravidas01@gmail.com");
		mv.addObject("user", user);
		mv.addObject("home", true);
		return mv;
	}*/
	
	/* @RequestMapping(value = "/updateInquiry", method = RequestMethod.POST)
	  public ModelAndView updateInqDetails(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("inquiry") Inquiry inquiry) {
		 ModelAndView mv = new ModelAndView("home");
		 inquiryService.updateInquiry(inquiry);
	  return mv;
	  }*/
	
	/* @RequestMapping(value = "/registerProcess", method = RequestMethod.POST)
	  public ModelAndView addUser(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("user") User user) {
		 ModelAndView mv = new ModelAndView("register");
		System.out.println("Address : "+user.getAddress()+"   Email : "+user.getEmail());
	    //userService.register(user);
	  return mv;
	  }*/
	 
	 
	// Handling file upload request

}
