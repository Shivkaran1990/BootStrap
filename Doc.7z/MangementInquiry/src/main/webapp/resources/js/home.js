$(document).ready(function(){

$("#uploaddoc").click(function(){
	var file=$("#fileId").val();
	/* alert("we are here" +file); */
	

	$.ajax({
		type : "POST",
		contentType : "application/json",
		url : "${home}uploadFile",
		data : file,
		dataType : 'json',
		timeout : 100000,
		success : function(data) {
			console.log("SUCCESS: ", data);
			display(data);
		},
		error : function(e) {
			console.log("ERROR: ", e);
			display(e);
		},
		done : function(e) {
			console.log("DONE");
		}
	});

  });


  $("#update").click(function(){
   var fname=$("#fname").val();
    var lname=$("#lname").val();
	 var dob=$("#dob").val();
	  var ids=$("#ids").val();
	   var street=$("#street").val();
	    var city=$("#city").val();
		 var zip=$("#zip").val();
		  var acct=$("#acct").val();
      var state=$("#state").val();
	    var lphy=$("#lphy").val();
		 var zcodevisit=$("#zcodevisit").val();
		  var sex=$("#sex").val();
		  var ageyear=$("#ageyear").val();
	    var agemonth=$("#agemonth").val();
		 var phy1=$("#phy1").val();
		  var phy2=$("#phy2").val();
		  var nlp=$("#nlp").val();
	    var nphydate=$("#nphydate").val();
		 var apptsetdate=$("#apptsetdate").val();
		  var apptBy=$("#apptBy").val();
		  var newPh=$("#newPh").val();
	    var newph1=$("#newph1").val();
		 var newph2=$("#newph2").val();
		  var newph3=$("#newph3").val();
		   var pastduedate=$("#pastduedate").val();
	    var upcomingday=$("#upcomingday").val();
		 var comment1=$("#comment1").val();
		  var comment2=$("#comment2").val();
  });
  
  $("#search").click(function(){
		var id=$("#inq_ids").val();
		//var urls="${contextPath}/getInq/"+id;
		   location.href = window.contextRoot +"/"+id;
			//var urls=window.contextRoot +"/inquiry/getDetails/"+id;
			var urls=window.contextRoot+"/" +id;
		$.ajax({
			type : "GET",
			dataType: 'json',
			url : urls,
			timeout : 1000000,
			success : function(response) {
				console.log("SUCCESS: ", response);
				//mapData(response);
				//window.location.reload();
			},
			error : function(e) {
				console.log("ERROR: ", e);
				//window.location.reload();
				
			},
			done : function(e) {
				console.log("DONE");
				//window.location.reload();
			}
		});

	  });
  
  
  
  
  
  
});

function mapData(data)
{
	mapInqDetails(data[0]);
	
 }
function mapInqDetails(data)
{
	clearData();
	document.getElementById("fname").innerHTML = data.firstname;
	document.getElementById("lname").innerHTML = data.lastname;
	document.getElementById("dob").innerHTML = data.dob;
	document.getElementById("Ids").innerHTML = data.inq_ids;
	document.getElementById("street").innerHTML = data.street;
	document.getElementById("city").innerHTML = data.city;
	document.getElementById("zip").innerHTML = data.zip;
	document.getElementById("acct").innerHTML = data.acct;
	document.getElementById("state").innerHTML = data.state;
	document.getElementById("lphy").innerHTML = data.last_phy;
	document.getElementById("zcodevisit").innerHTML = data.z_code_visit;
	document.getElementById("sex").innerHTML = data.sex;
	document.getElementById("ageyear").innerHTML = data.age_year;
	document.getElementById("agemonth").innerHTML = data.age_month;
	document.getElementById("phy1").innerHTML = data.phy1;
	document.getElementById("phy2").innerHTML = data.phy2;
	document.getElementById("nlp").innerHTML = data.nlp;
	//document.getElementById("nphydate").innerHTML = data.firstname;
	document.getElementById("apptsetdate").innerHTML = data.appt_setdate;
	document.getElementById("apptBy").innerHTML = data.apptBy;
	document.getElementById("newPh").innerHTML = data.newPh;
	document.getElementById("newph1").innerHTML = data.newph1;
	document.getElementById("newph2").innerHTML = data.newph2;
	document.getElementById("newph3").innerHTML = data.newph3;
	document.getElementById("pastduedate").innerHTML = data.past_duedate;
	document.getElementById("upcomingday").innerHTML = data.upcoming_day;
	document.getElementById("comment1").innerHTML = data.comment1;
	document.getElementById("comment2").innerHTML = data.comment2;
 }


function clearData()
{
	document.getElementById("fname").innerHTML = "" ;
	document.getElementById("lname").innerHTML = "" ;
	document.getElementById("dob").innerHTML = "" ;
	document.getElementById("Ids").innerHTML = "";
	document.getElementById("street").innerHTML = "" ;
	document.getElementById("city").innerHTML = "" ;
	document.getElementById("zip").innerHTML = "" ;
	document.getElementById("acct").innerHTML = "";
	document.getElementById("state").innerHTML = "" ;
	document.getElementById("lphy").innerHTML = "";
	document.getElementById("zcodevisit").innerHTML = "" ;
	document.getElementById("sex").innerHTML = "" ;
	document.getElementById("ageyear").innerHTML = "" ;
	document.getElementById("agemonth").innerHTML = "" ;
	document.getElementById("phy1").innerHTML = "" ;
	document.getElementById("phy2").innerHTML = "";
	document.getElementById("nlp").innerHTML = "" ;
	document.getElementById("nphydate").innerHTML = "" ;
	document.getElementById("apptsetdate").innerHTML = "" ;
	document.getElementById("apptBy").innerHTML = "" ;
	document.getElementById("newPh").innerHTML = "" ;
	document.getElementById("newph1").innerHTML = "" ;
	document.getElementById("newph2").innerHTML = "" ;
	document.getElementById("newph3").innerHTML = "";
	document.getElementById("pastduedate").innerHTML = "" ;
	document.getElementById("upcomingday").innerHTML = "" ;
	document.getElementById("comment1").innerHTML = "" ;
	document.getElementById("comment2").innerHTML = "" ;
	}

function searchName() {
	  // Declare variables 
	  var filter, table, tr, td, i, txtValue;
	// var name = document.getElementById("firstname").value;
	 var name = document.getElementById("myInput").value;
	 
	  var check = name.length;
	  console.log(check);
	  if(check>=3)
		  {
			  // location.href = window.contextRoot+"/";
				var urls=window.contextRoot+"/search/" +name;
			$.ajax({
				type : "GET",
				dataType: 'json',
				url : urls,
				processData: false,
				timeout : 1000000,
				success : function(response) {
					console.log("SUCCESS: ", response);
					showSearch(response);
					//mapData(response);
					//window.location.reload();
				},
				error : function(e) {
					console.log("ERROR: ", e);
					//window.location.reload();
					
				},
				done : function(e) {
					console.log("DONE");
					//window.location.reload();
				}
			});
		 
			 
		  }
	 
	}
function showSearch(data)
{
	  $("#namelist").empty();	  
	  for (i = 0; i < data.length; i++) {	  
			var x = document.createElement("A");
			  var t = document.createTextNode(data[i].firstname +" // "+ data[i].lastname +" // "+ data[i].dob);
			  x.setAttribute("href", window.contextRoot+"/" + data[i].inq_ids);
			  x.appendChild(t);
			  document.getElementById("namelist").appendChild(x);
	  }
	  
	  
	  
    /*var i;
    $("#myDropdown").empty();
    var x = document.createElement("A");
    document.getElementById("myDropdown").appendChild("");
	 for (i = 0; i < data.length; i++) {	  
		  var x = document.createElement("A");
		  var t = document.createTextNode(data[i].firstname);
		  x.setAttribute("href", "https://www.w3schools.com");
		  x.appendChild(t);
		  document.getElementById("myDropdown").appendChild(x);
		 
		 console.log(data[i].firstname);
	  }
	  document.getElementById("dropdownList").classList.add("dropdown-content");*/
 }
function checkDate()
{
	var l1=inquiry.last_phy;
var d1=new Date();
var d2=new Date();
console.log(l1);
return true;
 }